/**
 * Implements echo command, that is, prints all the arguments to this function to stdout.
 * However, it deals with only this case: echo something, i.e. it doesn't deal with quotations and prints them as though they are the part of the word
 * TODO: QUOTATIONS
 */

#include "shell.h"

void exec_echo(char *arg, char **args)
{
    for (int i = 1; args[i] != NULL && args[i][0] != '\0'; ++i)
    {
        print(args[i]);
        print(" ");
    }
    print("\n");
}