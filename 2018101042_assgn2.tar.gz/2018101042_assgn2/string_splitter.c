/**
 * This function parses the string based on a single separator (a function similar to strok command)
 * The ending of the char** is given by a '\0' character.
 * 
 * ASSUMPTIONS:
 * 1. No consecutive separators exist
 *    -- In case this happens the output for "I;am;a;a;;po" would be {"I","am","a","a","po"}
 * 2. All white spaces are spaces
 */

#include "shell.h"
int debug1 = 0;

int is_sep(char c, char sep)
{
    return (c == sep);
}

char **string_splitter(char *buffer, char sep)
{
    char **result = (char **)malloc(MAX_COMMANDS_PER_LINE * sizeof(char *));
    if (!result)
        memory_error();
    while (is_sep(buffer[0], sep))
        buffer++;
    if (debug1)
    {
        print("Buffer after removing all leading separators: ");
        print_n(buffer);
    }
    while (is_sep(buffer[strlen(buffer) - 1], sep))
        buffer[strlen(buffer) - 1] = '\0';
    if (debug1)
    {
        print("Buffer after removing all trailing separators: ");
        print_n(buffer);
    }
    //if the string is empty
    if (strcmp(buffer, "") == 0)
    {
        result[0] = (char *)malloc(MAX_ARGUMENTS_PER_COMMAND * sizeof(char));
        if (!result[0])
            memory_error();
        result[0][0] = '\0';
        return result;
    }
    int rowno = 0;
    for (int i = 0; i < strlen(buffer); i++)
    {
        result[rowno] = (char *)malloc(MAX_ARGUMENTS_PER_COMMAND * sizeof(char));
        if (!result[rowno])
            memory_error();
        int j = 0;
        while (buffer[i] != '\0' && !is_sep(buffer[i], sep))
            result[rowno][j++] = buffer[i++];
        result[rowno][j] = '\0';
        if (debug1)
            print_n(result[rowno]);
        rowno++;
    }
    result[rowno] = (char *)malloc(MAX_ARGUMENTS_PER_COMMAND * sizeof(char));
    if (!result[rowno])
        memory_error();
    result[rowno][0] = '\0';
    return result;
}
