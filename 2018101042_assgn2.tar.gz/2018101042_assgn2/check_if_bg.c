/**
 * This function checks whether the given parsed string (separated by spaces) can qualify as a background process or not, i.e. it should have an & as its last item. 
 * It also modifies the string and removes the trailing \0 and & character
 * If & appears in the middle of the argument, it would be ignored
 */

#include "shell.h"

int check_if_bg(char **args)
{
    int i = 0;
    for (; args[i][0] != '\0'; i++)
        ;
    args[i] = NULL; //nullify the last argument
    if (strcmp(args[i - 1], "&") == 0)
    {
        args[i - 1] = NULL; //nullify the & argument
        return 1;
    }
    return 0;
}