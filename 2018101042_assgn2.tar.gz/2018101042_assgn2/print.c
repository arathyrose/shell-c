/**
 * This file contains the functions print and print_n which prints a given string to stdout (with and without a trailing newline)
 * and some basic error handling
 * - memory error
 */

#include "shell.h"

void print(char *s)
{
    write(1, s, strlen(s));
}

void print_n(char *s)
{
    print(s);
    print("\n");
}

void memory_error()
{
    perror("Memory");
    exit(1);
}
