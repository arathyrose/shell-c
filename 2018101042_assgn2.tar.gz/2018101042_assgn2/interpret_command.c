/**
 * Considers a command stored in the buffer and breaks it down into individual commands and then into argumnets and executes them based on whether it is builtin or not
 */

#include "shell.h"

void interpret_command(char *cmd)
{
    char **cmds = string_splitter(cmd, ';'); //get each command separated by semicolons
    for (int i = 0; cmds[i] != NULL && cmds[i][0] != '\0'; i++)
    {
        char **args = string_splitter(cmds[i], ' ');
        if (args[0][0] == '\0') //that is, no command has been given
            continue;
        //Check whether it is a builtin command and execute it
        if (execute_builtin_commands(args) == 0)
        {
            //If it is not a builtin command, check whether it is a background process
            isbg = check_if_bg(args);
            int pid = fork();
            if (pid == 0)
            {
                //child process
                if (isbg)
                    setpgid(0, 0);
                if (execvp(args[0], args) < 0) //If the command does not exist
                    perror("No command found");
                exit(0);
            }
            else
            {
                int i;
                if (!isbg)
                    waitpid(pid, &i, WUNTRACED); //if it is not a background process, wait, till it gets over
                else
                {
                    struct P *proc;
                    strcpy(proc->pname, args[0]);
                    proc->pid = pid;
                    proc->next = running;
                    running = proc;
                }
            }
        }
        free(args);
    }
    free(cmds);
}