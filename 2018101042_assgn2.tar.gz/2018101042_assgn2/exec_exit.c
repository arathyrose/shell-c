/**
 * Exits the shell normally and successfully
 */

#include "shell.h"

void exec_exit(char *str, char **args)
{
    print_n("Exiting the shell now...");
    exit(EXIT_SUCCESS);
}