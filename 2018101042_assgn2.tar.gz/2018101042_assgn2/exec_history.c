/**
 * Displays the last  MAX_HISTORY(max) or argument number of previous commands entered
 */

#include "shell.h"

void exec_history(char *arg, char **args)
{
    if (history_lines == 0)
    {
        print_n("No commands entered yet");
        return;
    }
    int lines_to_display = MAX_HISTORY;
    if (args[1][0] != '\0') //
    {
        if (args[2] != NULL && args[2][0] != '\0')
        {
            print_n("Invalid usage\nUsage: history <n>");
            return;
        }
        int arg1 = atoi(args[1]);
        if (arg1 == 0)
        {
            print_n("Invalid usage\nUsage: history <n>");
            return;
        }
        lines_to_display = (arg1 > history_lines) ? history_lines : arg1;
    }
    lines_to_display = (MAX_HISTORY > lines_to_display) ? lines_to_display : MAX_HISTORY;
    for (int i = history_lines - lines_to_display; i < history_lines; i++)
        print_n(history[i]);
}
