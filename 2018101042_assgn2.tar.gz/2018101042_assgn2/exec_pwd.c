
/**
 * Prints the current/present working directory
 */

#include "shell.h"

void exec_pwd(char *arg, char **args)
{
    if (args[1][0] != '\0')
        print("pwd: too many arguments\n");
    else
    {
        char *buffer = (char *)malloc((MAX_CURRENT_DIR) * sizeof(char));
        if (!buffer)
            memory_error();
        getcwd(buffer, MAX_CURRENT_DIR); //this would give the absolute working directory
        print_n(buffer);
        free(buffer);
    }
}