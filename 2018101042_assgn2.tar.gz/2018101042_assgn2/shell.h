// List of all header files
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <stddef.h>
#include <pwd.h>
#include <grp.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/types.h>
#include <fcntl.h>
#include <signal.h>
#include <stdbool.h>
#include <unistd.h>
#include <math.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/time.h>

//list of constants
#define MAX_USERNAME_SIZE 1024
#define MAX_SYSTEM_NAME 1024
#define MAX_CURRENT_DIR 1024
#define MAX_LINE_LENGTH 1024
#define MAX_BUFFER_LENGTH 1024
#define MAX_COMMANDS_PER_LINE 1024
#define MAX_ARGUMENTS_PER_COMMAND 1024
#define MAX_SPID_LENGTH 10
#define MAX_HISTORY 20

#ifndef SHELL_H
#define SHELL_H

//list of global variables
char home[MAX_CURRENT_DIR];
int isbg;
int size_running_procs;
char history[1000000][MAX_LINE_LENGTH]; //history array to store history commands(can store maximum 100000 commands): should not go overflow
int history_lines;

//function prototypes

//printing lines into stdout
void print(char *s);
void print_n(char *s);

//error handling
void memory_error();

//display features
void display_shell_prompt();
void display_killed_children();

//read, intepret and run commands
char *read_command();
void interpret_command(char *cmd);
int execute_builtin_commands(char **args); //returns 0 if the command was a builtin and executes it. returns 1 if it is not and doesn't execute it

//auxillary functions
int check_if_bg(char **args);
char **string_splitter(char *buffer, char sep);
void display_line_ls(char *filepath, char *filename);
void display_permissions_ls(int mode);

//built-in commands
void exec_exit(char *arg, char **args);
void exec_echo(char *arg, char **args);
void exec_cd(char *arg, char **args);
void exec_pwd(char *arg, char **args);
void exec_pinfo(char *str, char **args);
void exec_ls(char *arg, char **args);
void exec_nightswatch(char *arg, char **args);
void exec_history(char *arg, char **args);

//all running processes implemented as a linked list
struct P
{
    char pname[128];
    int pid;
    struct P *next;
};
struct P *running;

#endif