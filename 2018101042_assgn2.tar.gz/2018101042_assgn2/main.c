/**
 * The main function 
 */

#include "shell.h"

int main()
{
    history_lines = 0;
    running = NULL;
    char *buffer;
    getcwd(home, MAX_CURRENT_DIR);
    while (1)
    {
        display_killed_children();
        display_shell_prompt();
        buffer = read_command();
        interpret_command(buffer);
        strcpy(history[history_lines++], buffer); //Updating the history array with input buffer
    }
    free(buffer);
}
