/**
 * An auxillary function that is used to display the file details when the command ls -l is called
 */

#include "shell.h"

int deb = 0;

void display_line_ls(char *filepath, char *filename)
{
    struct stat file_status;
    if (stat(filepath, &file_status) != 0)
    {
        if (deb)
            print_n(filepath);
        perror("Reading done wrong");
        return;
    }
    display_permissions_ls(file_status.st_mode);
    char buffer[MAX_BUFFER_LENGTH];
    struct passwd *pw = getpwuid(file_status.st_uid);
    struct group *gr = getgrgid(file_status.st_gid);
    if (pw == 0 || gr == 0)
    {
        perror("Error : User or group not found");
        return;
    }
    sprintf(buffer, "%2zu %s %s %7zu", file_status.st_nlink, pw->pw_name, gr->gr_name, file_status.st_size);
    print(buffer);
    // If pw != 0, pw->pw_name contains the user name
    // If gr != 0, gr->gr_name contains the group name
    char date[16];
    strftime(date, 16, "%b %2d %2I:%2M", gmtime(&(file_status.st_mtime)));
    sprintf(buffer, " %s %s\n", date, filename);
    print(buffer);
}
