/**
 * Displays the shell prompt (specification 1)
 * using colors
 * It also takes care when the current working directory is inside the shell home directory by displaying it as ~/...
 */

#include "shell.h"

int debug = 0;

void display_shell_prompt()
{
    //Getting the username and system name
    char username[MAX_USERNAME_SIZE];
    char system_name[MAX_SYSTEM_NAME];
    char current_directory[MAX_CURRENT_DIR];

    //initialisation
    gethostname(system_name, MAX_SYSTEM_NAME);
    getlogin_r(username, MAX_USERNAME_SIZE);
    getcwd(current_directory, MAX_CURRENT_DIR); //this would give the absolute working directory
    if (debug)
        print(current_directory);

    //now check whether it is reducible by checking whether it is in home directory
    if (strncmp(current_directory, home, strlen(home)) == 0)
    {
        char *s = current_directory;
        *s++ = '~';
        for (int j = strlen(home); current_directory[j] != '\0'; j++)
            *s++ = current_directory[j];
        *s = '\0';
    }
    if (debug)
        print(current_directory);

    //now write the prompt into the buffer and print it
    char buffer[MAX_CURRENT_DIR + MAX_SYSTEM_NAME + MAX_USERNAME_SIZE + 38];
    sprintf(buffer, "\033[0m<\033[0;32m%s@%s:\033[0m\033[0;34m%s\033[0m> ", username, system_name, current_directory);
    print(buffer);
}
