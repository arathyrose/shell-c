/**
 * Display the name and pid of all children killed or stopped within the next execution of the command
 * Runs on pressing enter
 */

#include "shell.h"

void print_proc_details(struct P *proc, int status)
{
    char buffer[MAX_LINE_LENGTH];
    if (WIFEXITED(status))
        sprintf(buffer, "%s with pid %d exited\nnormally with status %d", proc->pname, proc->pid, WEXITSTATUS(status));
    else
        sprintf(buffer, "%s with pid %d exited\nabnormally (terminated by a signal) with error status %d", proc->pname, proc->pid, WEXITSTATUS(status));
    print_n(buffer);
}

void display_killed_children()
{
    int pid, status;
    while (1)
    {
        int pid = waitpid(-1, &status, WNOHANG | WUNTRACED); //WNOHANG is for killed children; WUNTRACED is for stopped children
        if (pid <= 0)
            break;
        if (WIFEXITED(status) || WIFSIGNALED(status))
        {
            struct P *prev_proc = running, *current_proc = running;
            if (current_proc != NULL && current_proc->pid == pid)
            {
                running = running->next;
                print_proc_details(current_proc, status);
                free(current_proc);
                return;
            }
            while (current_proc != NULL && current_proc->pid != pid)
            {
                prev_proc = current_proc;
                current_proc = current_proc->next;
            }
            if (current_proc != NULL)
            {
                prev_proc->next = current_proc->next;
                print_proc_details(current_proc, status);
                free(current_proc);
                return;
            }
        }
    }
}